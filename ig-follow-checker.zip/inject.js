/**
 * inject.js — runs in PAGE context (not extension context).
 * Wraps window.fetch so we can read Instagram's own API responses
 * before they disappear, then forwards the data to content.js via postMessage.
 */
(function () {
  if (window.__igfcInjected) return;
  window.__igfcInjected = true;

  const _fetch = window.fetch.bind(window);

  window.fetch = async function (input, init) {
    const response = await _fetch(input, init);

    try {
      const url = typeof input === "string" ? input : input?.url ?? "";

      // Intercept followers list  →  /friendships/{id}/followers/
      // Intercept following list  →  /friendships/{id}/following/
      if (/\/friendships\/\d+\/(followers|following)/.test(url)) {
        const listType = url.includes("/following") ? "following" : "followers";
        const clone = response.clone();

        clone.json().then((data) => {
          if (!Array.isArray(data?.users)) return;

          window.postMessage(
            {
              __igfc: true,
              listType,
              users: data.users.map((u) => ({
                pk:               String(u.pk),
                username:         u.username,
                // On the FOLLOWERS list:
                //   followed_by_viewer = true  → you follow them back  (mutual)
                //   followed_by_viewer = false → you don't follow back (one-way follower)
                // On the FOLLOWING list:
                //   followed_by_viewer is always true (they're people YOU follow)
                //   We look for follows_viewer / is_follower for the reverse direction
                followed_by_viewer: u.followed_by_viewer ?? null,
                follows_viewer:     u.follows_viewer ?? u.is_follower ?? null,
              })),
            },
            "*"
          );
        }).catch(() => {});
      }
    } catch (_) {}

    return response;
  };
})();

/**
 * content.js — runs in the Instagram tab (extension context).
 *
 * 1. Injects inject.js into the page so we can intercept Instagram's fetch calls.
 * 2. Listens for the postMessage with follower/following data.
 * 3. Observes the DOM for follower list rows and stamps each with a badge.
 */

/* ─── 1. Inject page-level script ─────────────────────────────────────── */
(function injectPageScript() {
  const s = document.createElement("script");
  s.src = chrome.runtime.getURL("inject.js");
  s.onload = () => s.remove();
  (document.head || document.documentElement).appendChild(s);
})();

/* ─── 2. In-memory store of user follow data ──────────────────────────── */
// key: username (string)  value: { followsBack: bool | null, listType: string }
const store = new Map();

window.addEventListener("message", (e) => {
  if (!e.data?.__igfc || e.source !== window) return;

  const { users, listType } = e.data;
  users.forEach((u) => {
    // For FOLLOWERS list: we care about followed_by_viewer (do YOU follow them?)
    // For FOLLOWING list: we care about follows_viewer (do THEY follow you?)
    const followsBack =
      listType === "followers"
        ? u.followed_by_viewer
        : u.follows_viewer;

    store.set(u.username, { followsBack, listType });
  });

  stampAllVisibleRows();
});

/* ─── 3. Badge injection ──────────────────────────────────────────────── */
const STAMPED_ATTR = "data-igfc-stamped";

function makeBadge(followsBack, listType) {
  const badge = document.createElement("span");
  badge.className = followsBack ? "igfc-yes" : "igfc-no";

  if (listType === "followers") {
    badge.textContent = followsBack ? "✓ Following back" : "✗ Not following back";
  } else {
    // On the "following" list, label from their perspective
    badge.textContent = followsBack ? "✓ Follows you" : "✗ Doesn't follow you";
  }

  return badge;
}

function stampRow(row, username) {
  const info = store.get(username);
  if (!info) return;
  if (info.followsBack === null) return; // API didn't return the field

  // Don't re-stamp unless data changed
  const prev = row.getAttribute(STAMPED_ATTR);
  const key  = `${username}:${info.followsBack}`;
  if (prev === key) return;

  // Remove any old badge
  row.querySelector(".igfc-yes, .igfc-no")?.remove();

  const badge = makeBadge(info.followsBack, info.listType);

  // Insert before the Follow/Following button, or append to row
  const btn = row.querySelector("button");
  if (btn) {
    btn.before(badge);
  } else {
    row.appendChild(badge);
  }

  row.setAttribute(STAMPED_ATTR, key);
}

function stampAllVisibleRows() {
  // Instagram renders the followers/following list inside a dialog.
  // Each user row contains an anchor whose href is "/<username>/".
  const dialog = document.querySelector('div[role="dialog"]');
  if (!dialog) return;

  // Grab every profile link inside the dialog
  dialog.querySelectorAll('a[href^="/"]').forEach((link) => {
    const href = link.getAttribute("href") ?? "";
    // Profile hrefs look like "/username/" — no sub-paths, no dots
    const match = href.match(/^\/([^/]+)\/?$/);
    if (!match) return;

    const username = match[1];
    if (!store.has(username)) return;

    // Walk up to find the "row" container — the closest flex div that
    // is a direct child of the scrollable list
    const row =
      link.closest("li") ||
      link.closest('[role="button"]')?.parentElement ||
      link.closest('div[style*="display"]')?.parentElement ||
      link.parentElement?.parentElement?.parentElement;

    if (row) stampRow(row, username);
  });
}

/* ─── 4. MutationObserver — handles infinite scroll & dialog open ─────── */
const observer = new MutationObserver(() => stampAllVisibleRows());
observer.observe(document.body, { childList: true, subtree: true });

/* ─── 5. Styles ───────────────────────────────────────────────────────── */
const css = `
  .igfc-yes,
  .igfc-no {
    display: inline-block;
    font-size: 11px;
    font-weight: 600;
    padding: 3px 9px;
    border-radius: 12px;
    white-space: nowrap;
    margin-right: 8px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    vertical-align: middle;
  }
  .igfc-yes {
    background: #d1fae5;
    color: #065f46;
  }
  .igfc-no {
    background: #fee2e2;
    color: #991b1b;
  }
`;
const styleEl = document.createElement("style");
styleEl.textContent = css;
(document.head || document.documentElement).appendChild(styleEl);
